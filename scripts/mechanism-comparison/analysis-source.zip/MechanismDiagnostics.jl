module MechanismDiagnostics
using Oceananigans, Statistics, LinearAlgebra, FFTW, JLD2, Printf
using Oceananigans.Architectures: device, architecture, on_architecture, synchronize
using Oceananigans.StokesDrifts: x_curl_Uˢ_cross_U, z_curl_Uˢ_cross_U
using Oceananigans.Operators: ∂xᶠᶜᶜ, ∂zᶜᶜᶠ
using Oceananigans: TendencyCallsite
using Oceananigans.Architectures.KA: @kernel, @index

# All diagnostics read the model. No model field or tendency is ever assigned.
# Physical products below use a centered conservative reference; the difference
# from the actual WENO tendency is stored explicitly, never called wave transfer.
const LABELS = ("u", "v", "w", "Gu", "Gv", "Gw", "wave_u", "wave_w",
                "Fuu", "Fuw", "Fww", "p", "E_native", "power_G", "power_wave", "divmax")
const COMPONENTS = (:eddy, :mean, :threeD, :wave, :numerical)

@kernel function reduce_planes!(A, grid, U, G, stokes, p, t, ny, nz, dx, dy, dz)
    i,k = @index(Global, NTuple)
    u,v,w = U.u,U.v,U.w
    @inbounds begin
        for n in 1:16; A[i,k,n]=0.0; end
        for j in 1:ny
            ww=w[i,j,k]
            A[i,k,3]+=ww
            if 1<k<nz+1
                A[i,k,6]+=G.w[i,j,k]
                A[i,k,8]+=z_curl_Uˢ_cross_U(i,j,k,grid,stokes,U,t)
                A[i,k,10]+=(u[i,j,k-1]+u[i,j,k])*(w[i-1,j,k]+ww)/4
            end
            if k<=nz
                uu,vv=u[i,j,k],v[i,j,k]
                gu,gv=G.u[i,j,k],G.v[i,j,k]
                sw=x_curl_Uˢ_cross_U(i,j,k,grid,stokes,U,t)
                wb,wt=w[i,j,k],w[i,j,k+1]
                gb=k==1 ? 0.0 : G.w[i,j,k]
                gt=k==nz ? 0.0 : G.w[i,j,k+1]
                sb=k==1 ? 0.0 : z_curl_Uˢ_cross_U(i,j,k,grid,stokes,U,t)
                st=k==nz ? 0.0 : z_curl_Uˢ_cross_U(i,j,k+1,grid,stokes,U,t)
                A[i,k,1]+=uu; A[i,k,2]+=vv
                A[i,k,4]+=gu; A[i,k,5]+=gv; A[i,k,7]+=sw
                A[i,k,9]+=(uu+u[i+1,j,k])^2/4
                A[i,k,11]+=(wb+wt)^2/4
                A[i,k,12]+=p[i,j,k]
                A[i,k,13]+=(uu^2+vv^2+(wb^2+wt^2)/2)/2
                A[i,k,14]+=uu*gu+vv*gv+(wb*gb+wt*gt)/2
                A[i,k,15]+=uu*sw+(wb*sb+wt*st)/2
                div=(u[i+1,j,k]-uu)/dx+(v[i,j+1,k]-vv)/dy+(wt-wb)/dz
                A[i,k,16]=max(A[i,k,16],abs(div))
            end
        end
        for n in 1:15; A[i,k,n]/=ny; end
    end
end

# A GPU-backed noncontiguous interior view is not a supported input to the
# Statistics.mean fallback. Reduce pressure explicitly with the same backend
# kernel strategy used for all the other transverse averages.
@kernel function reduce_pressure!(P,p,ny)
    i,k=@index(Global,NTuple)
    s=0.0
    @inbounds for j in 1:ny; s+=p[i,j,k]; end
    @inbounds P[i,k]=s/ny
end

function pressure_plane(model;field=model.pressures.pNHS)
    nx,ny,nz=size(model.grid);arch=architecture(model)
    P=on_architecture(arch,zeros(nx,nz))
    reduce_pressure!(device(arch),(16,8))(P,field,ny;ndrange=(nx,nz))
    synchronize(arch)
    Array(P)
end

function packet(model, buffer)
    nx,ny,nz=size(model.grid); arch=architecture(model)
    reduce_planes!(device(arch),(16,8))(buffer,model.grid,model.velocities,model.timestepper.Gⁿ,
        model.stokes_drift,model.pressures.pNHS,model.clock.time,ny,nz,1/nx,.5/ny,1/nz;ndrange=(nx,nz+1))
    synchronize(arch)
    A=Array(buffer)
    all(isfinite,A) || error("Nonfinite diagnostic field")
    return A
end

um(A)=@view A[:,1:end-1,1]
wm(A)=@view A[:,:,3]
plane(A,n)=@view A[:,1:end-1,n]
face(A,n)=@view A[:,:,n]
xfwd(a)=circshift(a,(-1,0))
xback(a)=circshift(a,(1,0))

function products(u,w)
    nx,nz=size(u)
    fuu=((u+xfwd(u))/2).^2
    fww=((w[:,1:end-1]+w[:,2:end])/2).^2
    fuw=zeros(nx,nz+1)
    fuw[:,2:end-1].=(u[:,1:end-1]+u[:,2:end]).*(w[:,2:end-1]+xback(w[:,2:end-1]))./4
    return fuu,fuw,fww
end

function divergence_force(fuu,fuw,fww,dx,dz)
    fu=-(fuu-xback(fuu))/dx-diff(fuw;dims=2)/dz
    fw=zeros(size(fuw))
    fw[:,2:end-1].=-(xfwd(fuw[:,2:end-1])-fuw[:,2:end-1])/dx-diff(fww;dims=2)/dz
    return (u=fu,w=fw)
end
add(a,b)=(u=a.u+b.u,w=a.w+b.w)
sub(a,b)=(u=a.u-b.u,w=a.w-b.w)
scale(a,r)=(u=r*a.u,w=r*a.w)
weighted(a,b,dt)=scale(add(scale(a,.25),scale(b,.75)),dt)

function curl(a,dx,dz)
    c=zeros(size(a.w))
    c[:,2:end-1].=diff(a.u;dims=2)/dz-(a.w[:,2:end-1]-xback(a.w[:,2:end-1]))/dx
    c
end
function reduced_q(A,S,dx,dz)
    curl((u=um(A),w=wm(A)),dx,dz).-reshape(S,1,:)
end
function decompose(A,dx,dz)
    u,w=um(A),wm(A)
    all2=divergence_force(products(u,w)...,dx,dz)
    ue=u.-mean(u;dims=1)
    eddy=divergence_force(products(ue,w)...,dx,dz)
    physical=divergence_force(plane(A,9),face(A,10),plane(A,11),dx,dz)
    wave=(u=copy(plane(A,7)),w=copy(face(A,8)))
    actual=(u=copy(plane(A,4)),w=copy(face(A,6)))
    (eddy=eddy,mean=sub(all2,eddy),threeD=sub(physical,all2),wave=wave,numerical=sub(sub(actual,wave),physical))
end

"Conservative transport reference for reduced q at native x/z corners."
function pv_transport(A,q,dx,dz)
    u,w=um(A),wm(A);nx,nz=size(u)
    uz=zeros(nx,nz+1);uz[:,2:end-1].=(u[:,1:end-1]+u[:,2:end])/2
    uz[:,1].=u[:,1];uz[:,end].=u[:,end]
    fx=((uz+xfwd(uz))/2).*((q+xfwd(q))/2)
    wz=(w[:,1:end-1]+w[:,2:end])/2
    fz=((wz+xback(wz))/2).*((q[:,1:end-1]+q[:,2:end])/2)
    adv=zeros(size(q))
    adv[:,2:end-1].=-(fx[:,2:end-1]-xback(fx[:,2:end-1]))/dx-diff(fz;dims=2)/dz
    return adv,fz
end

zmean_faces(a)=vec(mean(a;dims=1))
function face_integral(a,dz)
    dz*(sum(a[:,2:end-1])+(sum(a[:,1])+sum(a[:,end]))/2)/size(a,1)
end
function energy2(A)
    u,w=um(A),wm(A)
    mean(u.^2)/2+mean((w[:,1:end-1].^2+w[:,2:end].^2)/2)/2
end
function pressure_gradient(p,dx,dz)
    gx=(p-xback(p))/dx;gz=zeros(size(p,1),size(p,2)+1)
    gz[:,2:end-1].=diff(p;dims=2)/dz
    (u=gx,w=gz)
end

function cospectrum(a,b)
    nx=size(a,1); h1=rfft(a,1)/nx;h2=rfft(b,1)/nx
    c=real.(conj.(h1).*h2); c[2:end-1,:].*=2
    return c
end
function work_spectrum(A,F)
    cu=cospectrum(um(A),F.u);cw=cospectrum(wm(A),F.w)
    cu+(cw[:,1:end-1]+cw[:,2:end])/2
end

mutable struct Recorder
    out::String; buffer; nx::Int; nz::Int; Te::Float64; u0::Float64; S::Vector{Float64}
    old; mid; pacc; iteration::Int; lastkey
    phaseio::IO; stepi::IO; profiles::IO; timing::IO
    nextdense::Float64; started::Float64; lastdense_t::Float64
    cumU::Dict{Symbol,Vector{Float64}}; cumPV::Dict{Symbol,Vector{Float64}}
    budget_error::Float64; q_error::Float64; pressure_error::Float64
    phase_count::Int; dense_count::Int; filebytes::Int
end

function Recorder(model,out,Te,u0,waves)
    nx,ny,nz=size(model.grid);mkpath(joinpath(out,"dense"))
    S=waves==1 ? .25*exp.(8 .* collect(range(-1,0;length=nz+1))) : zeros(nz+1)
    buffer=on_architecture(architecture(model),zeros(nx,nz+1,16))
    si=open(joinpath(out,"steps.csv"),"w")
    println(si,"t,iteration,dt,E_native,E_reduced_xz,E_transverse,mean_energy,momentum,q_half2,divmax,mean_RK_error,q_RK_error,velocity_projection_error,full_power_G,full_power_wave,full_energy_time_residual")
    ph=open(joinpath(out,"phase.bin"),"w");pr=open(joinpath(out,"budgets.bin"),"w")
    ti=open(joinpath(out,"phase-times.csv"),"w");println(ti,"t,iteration,offset_bytes")
    cu=Dict(k=>zeros(nz) for k in COMPONENTS)
    cp=Dict(k=>zeros(nz+1) for k in (:transport,:threeD,:spatial_residual))
    r=Recorder(out,buffer,nx,nz,Te,u0,S,nothing,nothing,zeros(nx,nz),-1,nothing,ph,si,pr,ti,
      0.0,time(),0.0,cu,cp,0.,0.,0.,0,0,0)
    open(joinpath(out,"schema.txt"),"w") do io
        println(io,"packet labels: ",join(LABELS,","))
        println(io,"dense/*.jld2: packet Float32 [nx,nz+1,1:13]; q Float32; time,stage,iteration; spectra; cumulative profiles Float64.")
        println(io,"phase.bin: each record ComplexF32 [min(33,nx/2+1),nz] u, then [min(33,nx/2+1),nz+1] w; FFT normalized by nx; native staggering. phase-times.csv records actual times and byte offsets.")
        println(io,"budgets.bin per full step: Float64 t,dt; U[nz],Q[nz+1],q2[nz+1],Rphysical[nz+1],R2[nz+1],Rnative[nz+1]; then cumulative dU[nz] in ",COMPONENTS,"; cumulative half-q2 profiles[nz+1] in transport,threeD,spatial_residual.")
        println(io,"RK3 integrated tendencies use weights 1/4,0,3/4. Pressure corrections use actual substage durations. PV variance allocation uses endpoint midpoint q so sums reproduce the discrete change; it is not a continuum material-conservation claim.")
        println(io,"q = dz u_bar_y - dx w_bar_y - S. Physical q transport and stress products are centered references. Spatial residual includes WENO/centering and Stokes-stencil differences. All spectra and work use native face norms, not interpolated-display norms.")
        println(io,"Full-domain horizontal spectra preserve depth; vertical fluxes/windows require analysis. Local work is not automatically conservative interscale transfer. Pressure in dense packet is last projection pressure, not an instantaneous continuum Poisson solve.")
    end
    r
end

function save_dense!(r,A,model,q)
    F=decompose(A,1/r.nx,1/r.nz)
    spectra=Dict(String(k)=>Float32.(work_spectrum(A,getproperty(F,k))) for k in COMPONENTS)
    spectra["energy_xz"]=Float32.(work_spectrum(A,(u=um(A),w=wm(A)))/2)
    pvadv,pvflux=pv_transport(A,q,1/r.nx,1/r.nz)
    p=joinpath(r.out,"dense",@sprintf("frame_%05d.jld2",r.dense_count))
    jldsave(p;packet=Float32.(A[:,:,1:13]),q=Float32.(q),pv_vertical_flux=Float32.(pvflux),
        spectra,t=model.clock.time,iteration=model.clock.iteration,stage=model.clock.stage,
        cumulative_mean=r.cumU,cumulative_PV_half2=r.cumPV,
        maximum_mean_RK_error=r.budget_error,maximum_PV_RK_error=r.q_error,
        maximum_projection_error=r.pressure_error)
    r.filebytes+=filesize(p);r.dense_count+=1;r.lastdense_t=model.clock.time
    r.nextdense=(floor(model.clock.time/r.Te*10+1e-8)+1)*.1*r.Te
end

function observe!(r,model)
    it,stage=model.clock.iteration,model.clock.stage
    key=(it,stage,model.clock.time);key==r.lastkey && return
    r.lastkey=key
    if stage==2
        p=pressure_plane(model)
        r.pacc .= model.clock.last_stage_Δt .* p
        return
    end
    A=packet(model,r.buffer)
    if stage==3
        r.pacc .+= model.clock.last_stage_Δt .* plane(A,12)
        r.mid=A
        return
    end
    stage==1 || error("Unexpected RK stage $stage")
    dx,dz=1/r.nx,1/r.nz; q=reduced_q(A,r.S,dx,dz)
    U=vec(mean(um(A);dims=1));Q=vec(mean(q;dims=1));q2=vec(mean(q.^2;dims=1))
    E=mean(plane(A,13)); Er=energy2(A); em=mean(U.^2)/2
    # Transverse-dependent energy uses the same native norm, including mean v.
    etrans=E-Er-mean(plane(A,2).^2)/2
    dt=0.; eu=0.;eq=0.;ev=0.;etime=0.
    if r.old!==nothing
        it==r.iteration+1 || error("Missing full step in recorder")
        r.mid!==nothing || error("Missing RK third stage")
        dt=model.clock.last_Δt
        r.pacc .+= model.clock.last_stage_Δt .* plane(A,12)
        G0=(u=plane(r.old,4),w=face(r.old,6));G2=(u=plane(r.mid,4),w=face(r.mid,6))
        dG=weighted(G0,G2,dt);dp=pressure_gradient(r.pacc,dx,dz)
        q0=reduced_q(r.old,r.S,dx,dz);dq=curl(dG,dx,dz)
        U0=vec(mean(um(r.old);dims=1)); dUm=vec(mean(dG.u;dims=1))
        eu=maximum(abs,U-U0-dUm)/r.u0
        eq=maximum(abs,q-q0-dq)/max(maximum(abs,r.S),r.u0*2π*9)
        ev=max(maximum(abs,um(A)-um(r.old)-dG.u+dp.u),maximum(abs,wm(A)-wm(r.old)-dG.w+dp.w))/r.u0
        max(eu,eq,ev)<1e-7 || error("RK/projection diagnostic closure failed: $eu $eq $ev")
        r.budget_error=max(r.budget_error,eu);r.q_error=max(r.q_error,eq);r.pressure_error=max(r.pressure_error,ev)
        F0=decompose(r.old,dx,dz);F2=decompose(r.mid,dx,dz)
        for k in COMPONENTS
            dF=weighted(getproperty(F0,k),getproperty(F2,k),dt)
            r.cumU[k].+=vec(mean(dF.u;dims=1))
        end
        adv0,_=pv_transport(r.old,q0,dx,dz)
        qstage=reduced_q(r.mid,r.S,dx,dz);adv2,_=pv_transport(r.mid,qstage,dx,dz)
        dtransport=dt*(.25*adv0+.75*adv2)
        d3=curl(weighted(F0.threeD,F2.threeD,dt),dx,dz)
        qmid=(q0+q)/2
        for (k,dqpart) in ((:transport,dtransport),(:threeD,d3),(:spatial_residual,dq-dtransport-d3))
            r.cumPV[k].+=vec(mean(qmid.*dqpart;dims=1))
        end
        # Actual energy change minus stage quadrature includes temporal and
        # projection effects; retain it explicitly rather than hide it in forcing.
        power=dt*(.25*mean(plane(r.old,14))+.75*mean(plane(r.mid,14)))
        etime=E-mean(plane(r.old,13))-power
    end
    hu=rfft(um(A),1)/r.nx;hw=rfft(wm(A),1)/r.nx;nk=min(33,size(hu,1))
    offset=position(r.phaseio);write(r.phaseio,ComplexF32.(hu[1:nk,:]));write(r.phaseio,ComplexF32.(hw[1:nk,:]))
    println(r.timing,model.clock.time,",",it,",",offset);r.phase_count+=1
    R=vec(mean(face(A,10);dims=1));R2=vec(mean(products(um(A),wm(A))[2];dims=1))
    advmean=vec(mean(plane(A,4)-plane(A,7);dims=1))
    Rnative=vcat(0.,-dz*cumsum(advmean))
    for x in (Float64(model.clock.time),Float64(dt),U,Q,q2,R,R2,Rnative);write(r.profiles,x);end
    for k in COMPONENTS;write(r.profiles,r.cumU[k]);end
    for k in (:transport,:threeD,:spatial_residual);write(r.profiles,r.cumPV[k]);end
    vals=(model.clock.time,it,dt,E,Er,etrans,em,mean(U),face_integral(q.^2,dz)/2,
        maximum(face(A,16)),eu,eq,ev,mean(plane(A,14)),mean(plane(A,15)),etime)
    println(r.stepi,join(vals,","))
    if model.clock.time+1e-10>=r.nextdense
        save_dense!(r,A,model,q)
        foreach(flush,(r.phaseio,r.timing,r.stepi,r.profiles))
    end
    r.old=A;r.mid=nothing;r.iteration=it
end

function finish!(r,model)
    if model.clock.time>r.lastdense_t+1e-6
        save_dense!(r,r.old,model,reduced_q(r.old,r.S,1/r.nx,1/r.nz))
    end
    foreach(close,(r.phaseio,r.timing,r.stepi,r.profiles))
end

end
