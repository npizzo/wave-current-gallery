module PacketDiagnostics
using Oceananigans, FFTW, JLD2, Statistics, TOML, Printf
using Oceananigans.Architectures: device, architecture, on_architecture, synchronize
using Oceananigans.Architectures.KA: @kernel, @index
import Oceananigans.StokesDrifts as SD

# Read-only diagnostics. The upstream solver, initialization and time steps are unchanged.
const LABELS = ("uL", "vL", "wL", "Gu", "Gv", "Gw", "vortex_u", "vortex_w",
    "Fuu", "Fuw", "Fww", "projection_pressure", "energy_native", "power_G",
    "power_vortex", "divmax", "dt_us", "dt_ws", "power_dt_stokes", "vortex_v",
    "dt_vs", "Fuv", "Fvw")
const COMPONENTS = (:resolved2D, :threeD, :vortex, :dt_stokes, :numerical)

@kernel function reduce!(A, grid, U, G, stokes, p, t, ny, nz, dx, dy, zc, zf)
    i,k = @index(Global, NTuple)
    u,v,w=U.u,U.v,U.w
    @inbounds begin
        for n in 1:23; A[i,k,n]=0.0; end
        for j in 1:ny
            ww=w[i,j,k]
            A[i,k,3]+=ww
            if 1<k<nz+1
                A[i,k,6]+=G.w[i,j,k]
                A[i,k,8]+=SD.z_curl_Uˢ_cross_U(i,j,k,grid,stokes,U,t)
                A[i,k,18]+=SD.∂t_wˢ(i,j,k,grid,stokes,t)
                a=(zf[k]-zc[k-1])/(zc[k]-zc[k-1])
                uf=(1-a)*u[i,j,k-1]+a*u[i,j,k]
                vf=(1-a)*v[i,j,k-1]+a*v[i,j,k]
                A[i,k,10]+=uf*(w[i-1,j,k]+ww)/2
                A[i,k,23]+=vf*(w[i,j-1,k]+ww)/2
            end
            if k<=nz
                uu,vv=u[i,j,k],v[i,j,k]
                gu,gv=G.u[i,j,k],G.v[i,j,k]
                su=SD.x_curl_Uˢ_cross_U(i,j,k,grid,stokes,U,t)
                sv=SD.y_curl_Uˢ_cross_U(i,j,k,grid,stokes,U,t)
                tu=SD.∂t_uˢ(i,j,k,grid,stokes,t)
                tv=SD.∂t_vˢ(i,j,k,grid,stokes,t)
                wb,wt=w[i,j,k],w[i,j,k+1]
                gb=k==1 ? 0.0 : G.w[i,j,k]
                gt=k==nz ? 0.0 : G.w[i,j,k+1]
                sb=k==1 ? 0.0 : SD.z_curl_Uˢ_cross_U(i,j,k,grid,stokes,U,t)
                st=k==nz ? 0.0 : SD.z_curl_Uˢ_cross_U(i,j,k+1,grid,stokes,U,t)
                tb=k==1 ? 0.0 : SD.∂t_wˢ(i,j,k,grid,stokes,t)
                tt=k==nz ? 0.0 : SD.∂t_wˢ(i,j,k+1,grid,stokes,t)
                A[i,k,1]+=uu; A[i,k,2]+=vv
                A[i,k,4]+=gu; A[i,k,5]+=gv; A[i,k,7]+=su; A[i,k,20]+=sv
                A[i,k,17]+=tu; A[i,k,21]+=tv
                A[i,k,9]+=(uu+u[i+1,j,k])^2/4
                A[i,k,11]+=(wb+wt)^2/4
                A[i,k,22]+=(uu+u[i,j-1,k])*(vv+v[i-1,j,k])/4
                A[i,k,12]+=p[i,j,k]
                A[i,k,13]+=(uu^2+vv^2+(wb^2+wt^2)/2)/2
                A[i,k,14]+=uu*gu+vv*gv+(wb*gb+wt*gt)/2
                A[i,k,15]+=uu*su+vv*sv+(wb*sb+wt*st)/2
                A[i,k,19]+=uu*tu+vv*tv+(wb*tb+wt*tt)/2
                div=(u[i+1,j,k]-uu)/dx+(v[i,j+1,k]-vv)/dy+(wt-wb)/(zf[k+1]-zf[k])
                A[i,k,16]=max(A[i,k,16],abs(div))
            end
        end
        for n in 1:23; n==16 || (A[i,k,n]/=ny); end
    end
end

@kernel function reduce_pressure!(P,p,ny)
    i,k=@index(Global,NTuple)
    s=0.0
    @inbounds for j in 1:ny; s+=p[i,j,k]; end
    @inbounds P[i,k]=s/ny
end

plane(A,n)=@view A[:,1:end-1,n]
face(A,n)=@view A[:,:,n]
xfwd(a)=circshift(a,(-1,0))
xback(a)=circshift(a,(1,0))
add(a,b)=(u=a.u+b.u,v=a.v+b.v,w=a.w+b.w)
sub(a,b)=(u=a.u-b.u,v=a.v-b.v,w=a.w-b.w)
scale(a,r)=(u=r*a.u,v=r*a.v,w=r*a.w)
weighted(a,b,dt)=scale(add(scale(a,.25),scale(b,.75)),dt)
velocity(A)=(u=plane(A,1),v=plane(A,2),w=face(A,3))
tendency(A)=(u=plane(A,4),v=plane(A,5),w=face(A,6))

struct Geometry
    nx::Int; nz::Int; dx::Float64; dy::Float64
    zc::Vector{Float64}; zf::Vector{Float64}; dz::Vector{Float64}; dc::Vector{Float64}
end
function geometry(model)
    nx,ny,nz=size(model.grid)
    zc=Float64.(Array(znodes(model.grid,Center())))
    zf=Float64.(Array(znodes(model.grid,Face())))
    Geometry(nx,nz,12/nx,.8/ny,zc,zf,diff(zf),diff(zc))
end
function curl(a,g)
    # Only native interior z-faces have a resolved curl; no fabricated wall PV.
    diff(a.u;dims=2)./reshape(g.dc,1,:) - (a.w[:,2:end-1]-xback(a.w[:,2:end-1]))/g.dx
end
function pressure_gradient(p,g)
    w=zeros(g.nx,g.nz+1)
    w[:,2:end-1].=diff(p;dims=2)./reshape(g.dc,1,:)
    (u=(p-xback(p))/g.dx,v=zeros(size(p)),w=w)
end
function zinterp(a,g)
    alpha=reshape((g.zf[2:end-1]-g.zc[1:end-1])./g.dc,1,:)
    (1 .-alpha).*a[:,1:end-1]+alpha.*a[:,2:end]
end
function products(a,g)
    fuw=zeros(g.nx,g.nz+1); fvw=similar(fuw);fill!(fvw,0)
    fuw[:,2:end-1].=zinterp(a.u,g).*(a.w[:,2:end-1]+xback(a.w[:,2:end-1]))/2
    fvw[:,2:end-1].=zinterp(a.v,g).*a.w[:,2:end-1]
    fuu=((a.u+xfwd(a.u))/2).^2
    fww=((a.w[:,1:end-1]+a.w[:,2:end])/2).^2
    fuv=a.u.*(a.v+xback(a.v))/2
    (;fuu,fuw,fww,fuv,fvw)
end
function divergence_force(f,g)
    fu=-(f.fuu-xback(f.fuu))/g.dx-diff(f.fuw;dims=2)./reshape(g.dz,1,:)
    fv=-(xfwd(f.fuv)-f.fuv)/g.dx-diff(f.fvw;dims=2)./reshape(g.dz,1,:)
    fw=zeros(g.nx,g.nz+1)
    fw[:,2:end-1].=-(xfwd(f.fuw[:,2:end-1])-f.fuw[:,2:end-1])/g.dx-diff(f.fww;dims=2)./reshape(g.dc,1,:)
    (;u=fu,v=fv,w=fw)
end
function decompose(A,g)
    resolved=divergence_force(products(velocity(A),g),g)
    physical=divergence_force((fuu=plane(A,9),fuw=face(A,10),fww=plane(A,11),fuv=plane(A,22),fvw=face(A,23)),g)
    vortex=(u=plane(A,7),v=plane(A,20),w=face(A,8))
    dt_stokes=(u=plane(A,17),v=plane(A,21),w=face(A,18))
    numerical=sub(sub(sub(tendency(A),vortex),dt_stokes),physical)
    (resolved2D=resolved,threeD=sub(physical,resolved),vortex=vortex,dt_stokes=dt_stokes,numerical=numerical)
end

function stokes(r,t)
    r.stokes_values(t)
end
qfield(r,A,t)=curl(sub(velocity(A),stokes(r,t)),r.g)

function pv_transport(A,q,g)
    # Centered physical reference for Lagrangian transport of the reduced Eulerian curl.
    # Flux divergence is on interior dual cells; wall-adjacent q uses linear extrapolation.
    u,w=plane(A,1),face(A,3)
    uz=zinterp(u,g)
    fx=(uz+xfwd(uz)).*(q+xfwd(q))/4
    qb=q[:,1]+(g.zf[1]-g.zf[2])/(g.zf[3]-g.zf[2])*(q[:,2]-q[:,1])
    qt=q[:,end]+(g.zf[end]-g.zf[end-1])/(g.zf[end-1]-g.zf[end-2])*(q[:,end]-q[:,end-1])
    qe=hcat(qb,q,qt)
    wz=(w[:,1:end-1]+w[:,2:end])/2
    fz=(wz+xback(wz)).*(qe[:,1:end-1]+qe[:,2:end])/4
    adv=-(fx-xback(fx))/g.dx-diff(fz;dims=2)./reshape(g.dc,1,:)
    adv,fz
end
meanx(a)=vec(mean(a;dims=1))
integrate(a,g)=sum(meanx(a).*g.dz)/sum(g.dz)
qintegrate(a,g)=sum(meanx(a).*g.dc)
function cospectrum(a,b)
    nx=size(a,1);c=real.(conj.(rfft(a,1)/nx).*(rfft(b,1)/nx))
    c[2:end-1,:].*=2
    c
end
function work_spectrum(A,F)
    U=velocity(A);cw=cospectrum(U.w,F.w)
    cospectrum(U.u,F.u)+cospectrum(U.v,F.v)+(cw[:,1:end-1]+cw[:,2:end])/2
end

mutable struct Recorder
    out::String; g::Geometry; buffer; zgpu; stokes_values
    old; mid; oldt::Float64; midt::Float64; pacc; iteration::Int; lastkey
    phaseio::IO; phase_times::IO; steps::IO
    cumU; cumPV; intervalF; intervalPV; errors::Vector{Float64}; dense_count::Int; lastdense::Float64
end
function Recorder(model,out,stokes_values)
    g=geometry(model);arch=architecture(model);mkpath(out)
    buffer=on_architecture(arch,zeros(g.nx,g.nz+1,23))
    zgpu=(on_architecture(arch,g.zc),on_architecture(arch,g.zf))
    ph=open(joinpath(out,"phase.bin"),"w");pt=open(joinpath(out,"phase-times.csv"),"w")
    println(pt,"t,iteration,offset_bytes")
    steps=open(joinpath(out,"steps.csv"),"w")
    println(steps,"t,iteration,energy_native,mean_u_energy,momentum,q_half2_interior,divmax,velocity_RK_error,q_RK_error,energy_time_projection_residual,power_G,power_vortex,power_dt_stokes")
    cu=Dict(k=>zeros(g.nz) for k in (COMPONENTS...,:pressure,:roundoff))
    cq=Dict(k=>zeros(g.nz-1) for k in (:transport,:resolved_source,:threeD,:vortex,:dt_stokes,:background_change,:numerical,:pressure,:roundoff))
    forces=Dict(k=>(u=zeros(g.nx,g.nz),v=zeros(g.nx,g.nz),w=zeros(g.nx,g.nz+1)) for k in keys(cu))
    pvs=Dict(k=>zeros(g.nx,g.nz-1) for k in keys(cq))
    r=Recorder(out,g,buffer,zgpu,stokes_values,nothing,nothing,0.,0.,zeros(g.nx,g.nz),-1,nothing,ph,pt,steps,cu,cq,forces,pvs,[0.,0.],0,-Inf)
    jldsave(joinpath(out,"grid.jld2"),false,IOStream;zc=g.zc,zf=g.zf,dx=g.dx,dy=g.dy,labels=collect(LABELS),q_z=g.zf[2:end-1])
    write(joinpath(out,"schema.txt"),"""
    All diagnostic operations are read-only. Native Float32 dynamics; Float64 transverse reductions and budget arithmetic.
    dense/*.jld2: all reduced planes with labels in grid.jld2; q = dz(uL-us)-dx(wL-ws) on interior x/z corners; analytic us/ws at native velocity nodes; exact grid coordinates; spectra, physical flux reference and cumulative budget profiles. interval_impulses stores the x/z-resolved RK-integrated force components INCLUDING pressure and roundoff since the preceding dense frame; interval_q_half2 stores the corresponding local variance allocation. interval_start/time give exact endpoints. These allow local packet budgets rather than only whole-tank averages.
    q is minus transverse Eulerian vorticity, not an assumed material invariant in 3D or in a travelling packet. Boundary PV is not fabricated; q variance integral covers only interior dual cells.
    RK-integrated tendencies use 1/4,0,3/4; projection increments use actual substage durations. Float32 update residual is retained explicitly. Physical stress/transport products use a centered reference; WENO difference remains numerical. Pressure output is projection pressure, not a separately solved instantaneous physical pressure.
    PV decomposition: transport reference, resolved-advection minus transport, 3D stress, vortex force, time-dependent Stokes acceleration, exact background-curl change, numerical, pressure curl, floating-point remainder. These separately stored terms may cancel; no source is silently attributed to homogenization.
    Spectra preserve physical depth with Fourier transforms only in periodic x. work_* is local tendency work, not automatically interscale flux: physical-space transport and window terms must be retained in the analysis. No uniform-z FFT is valid on this grid.
    phase.bin: per record ComplexF32 [min(65,nx/2+1),nz] uL, vL, then [min(65,nx/2+1),nz+1] wL. Normalized rfft/nx, native staggering. Use phase-times.csv and subtract the known packet before interpreting wave phases.
    The first analysis gate is evidence of jets in velocity, mean profiles and their evolution versus control and packet null. Mechanism claims require this gate; coherent packet/return flow is not turbulence-generated jets. Single seed, one resolution.
    """)
    r
end
function packet(r,model)
    arch=architecture(model);nx,ny,nz=size(model.grid)
    reduce!(device(arch),(16,4))(r.buffer,model.grid,model.velocities,model.timestepper.Gⁿ,model.stokes_drift,model.pressures.pNHS,model.clock.time,ny,nz,r.g.dx,r.g.dy,r.zgpu...;ndrange=(nx,nz+1))
    synchronize(arch);A=Array(r.buffer)
    all(isfinite,A)||error("Nonfinite diagnostic reduction")
    A
end
function pressure(r,model)
    arch=architecture(model);_,ny,_=size(model.grid)
    P=on_architecture(arch,zeros(r.g.nx,r.g.nz))
    reduce_pressure!(device(arch),(16,8))(P,model.pressures.pNHS,ny;ndrange=(r.g.nx,r.g.nz))
    synchronize(arch);Array(P)
end
function save_dense!(r,A,model,q)
    g=r.g;F=decompose(A,g)
    spectra=Dict(String(k)=>Float32.(work_spectrum(A,getproperty(F,k))) for k in COMPONENTS)
    spectra["energy_L"]=Float32.(work_spectrum(A,velocity(A))/2)
    s=stokes(r,Float64(model.clock.time));E=sub(velocity(A),s)
    spectra["energy_E_uv"]=Float32.((cospectrum(E.u,E.u)+cospectrum(E.v,E.v))/2)
    spectra["energy_E_w_faces"]=Float32.(cospectrum(E.w,E.w)/2)
    adv,flux=pv_transport(A,q,g)
    mkpath(joinpath(r.out,"dense"))
    jldsave(joinpath(r.out,"dense",@sprintf("frame_%04d.jld2",r.dense_count)),false,IOStream;
        planes=Float32.(A),q=Float32.(q),us=Float32.(s.u),ws=Float32.(s.w),spectra,
        pv_transport=Float32.(adv),pv_vertical_flux=Float32.(flux),
        cumulative_U=r.cumU,cumulative_q_half2=r.cumPV,maximum_closure_errors=r.errors,
        interval_impulses=Dict(k=>(u=Float32.(f.u),v=Float32.(f.v),w=Float32.(f.w)) for (k,f) in r.intervalF),
        interval_q_half2=Dict(k=>Float32.(v) for (k,v) in r.intervalPV),interval_start=isfinite(r.lastdense) ? r.lastdense : 0.,
        t=Float64(model.clock.time),iteration=model.clock.iteration)
    for f in values(r.intervalF),a in (f.u,f.v,f.w);fill!(a,0);end
    for a in values(r.intervalPV);fill!(a,0);end
    r.dense_count+=1;r.lastdense=Float64(model.clock.time)
    foreach(flush,(r.phaseio,r.phase_times,r.steps))
end
function observe!(r,model)
    it,stage=model.clock.iteration,model.clock.stage;t=Float64(model.clock.time)
    key=(it,stage,t);key==r.lastkey && return;r.lastkey=key
    if stage==2
        r.pacc .= model.clock.last_stage_Δt .* pressure(r,model)
        return
    end
    A=packet(r,model)
    if stage==3
        r.pacc .+=model.clock.last_stage_Δt .*plane(A,12)
        r.mid=A;r.midt=t;return
    end
    stage==1||error("Unexpected RK stage")
    g=r.g;q=qfield(r,A,t);U=meanx(plane(A,1));E=integrate(plane(A,13),g)
    ev=eq=et=0.
    if r.old!==nothing
        it==r.iteration+1||error("Missing diagnostic step")
        r.mid!==nothing||error("Missing RK stage")
        dt=Float64(model.clock.last_Δt)
        r.pacc .+= model.clock.last_stage_Δt .* plane(A,12)
        dp=pressure_gradient(r.pacc,g)
        dG=weighted(tendency(r.old),tendency(r.mid),dt)
        residual=add(sub(sub(velocity(A),velocity(r.old)),dG),dp)
        ev=max(maximum(abs,residual.u),maximum(abs,residual.v),maximum(abs,residual.w))/.05
        q0=qfield(r,r.old,r.oldt)
        ds= sub(stokes(r,t),stokes(r,r.oldt));dbackground=-curl(ds,g)
        qround=q-q0-curl(sub(dG,dp),g)-dbackground
        eq=maximum(abs,qround)/max(1.,maximum(abs,q))
        # Float32 update error is measured and saved. Only a gross diagnostic failure aborts.
        max(ev,eq)<.01 || error("Gross diagnostic closure failure: velocity=$ev PV=$eq")
        r.errors=max.(r.errors,[ev,eq])
        F0,F2=decompose(r.old,g),decompose(r.mid,g)
        dF=Dict(k=>weighted(getproperty(F0,k),getproperty(F2,k),dt) for k in COMPONENTS)
        for k in COMPONENTS; r.cumU[k].+=meanx(dF[k].u); end
        r.cumU[:pressure].-=meanx(dp.u);r.cumU[:roundoff].+=meanx(residual.u)
        dF[:pressure]=scale(dp,-1);dF[:roundoff]=residual
        for (k,f) in dF
            r.intervalF[k].u.+=f.u;r.intervalF[k].v.+=f.v;r.intervalF[k].w.+=f.w
        end
        adv0,_=pv_transport(r.old,q0,g)
        adv2,_=pv_transport(r.mid,qfield(r,r.mid,r.midt),g)
        dtransport=dt*(.25adv0+.75adv2);qmid=(q+q0)/2
        parts=Dict(k=>curl(dF[k],g) for k in COMPONENTS)
        parts[:transport]=dtransport
        parts[:resolved_source]=pop!(parts,:resolved2D)-dtransport
        parts[:background_change]=dbackground;parts[:pressure]=-curl(dp,g);parts[:roundoff]=qround
        for (k,dq) in parts
            allocation=qmid.*dq;r.cumPV[k].+=meanx(allocation);r.intervalPV[k].+=allocation
        end
        et=E-integrate(plane(r.old,13),g)-dt*(.25integrate(plane(r.old,14),g)+.75integrate(plane(r.mid,14),g))
    end
    offset=position(r.phaseio)
    for a in (plane(A,1),plane(A,2),face(A,3))
        h=rfft(a,1)/g.nx;write(r.phaseio,ComplexF32.(h[1:min(65,size(h,1)),:]))
    end
    println(r.phase_times,"$t,$it,$offset")
    vals=(t,it,E,sum(U.^2 .* g.dz)/sum(g.dz)/2,sum(U.*g.dz)/sum(g.dz),qintegrate(q.^2,g)/2,maximum(face(A,16)),ev,eq,et,integrate(plane(A,14),g),integrate(plane(A,15),g),integrate(plane(A,19),g))
    println(r.steps,join(vals,","))
    if it%5==0;save_dense!(r,A,model,q);end
    r.old=A;r.oldt=t;r.mid=nothing;r.iteration=it
end
function preflight!(r,model)
    A=packet(r,model);P=pressure(r,model)
    @assert maximum(abs,P-plane(A,12))<1e-12
    @assert size(qfield(r,A,Float64(model.clock.time)))==(r.g.nx,r.g.nz-1)
    @assert all(isfinite,qfield(r,A,Float64(model.clock.time)))
    F=decompose(A,r.g);total=reduce(add,(getproperty(F,k) for k in COMPONENTS))
    @assert maximum(abs,total.u-plane(A,4))<1e-10
    write(joinpath(r.out,"GPU-PREFLIGHT-PASSED.txt"),"Actual-state read-only reductions, pressure, PV geometry and tendency decomposition passed before integration.\n")
end
function finish!(r,model)
    if Float64(model.clock.time)>r.lastdense+1e-8
        save_dense!(r,r.old,model,qfield(r,r.old,Float64(model.clock.time)))
    end
    foreach(close,(r.phaseio,r.phase_times,r.steps))
    open(joinpath(r.out,"completed.toml"),"w") do io
        TOML.print(io,Dict("time_s"=>Float64(model.clock.time),"iterations"=>model.clock.iteration,"max_velocity_closure_error"=>r.errors[1],"max_q_closure_error"=>r.errors[2],"dense_frames"=>r.dense_count))
    end
end
end
