Read-only analysis of completed deep-water experiments, 7 Nov 2026.
Dependencies: Python 3, numpy, scipy, h5py, matplotlib, Pillow.
Raw fields remain in the research archive; this download does not contain them.
Set WAVE_ARCHIVE_ROOT to the parent of the campaign archive directories named in assessment.json.
reduce.py: pass a case name and output-directory destination (see --help). It reads existing JLD2/HDF5 and binary diagnostics.
Cases: coarse-deep-s1, coarse-none-s1, fine-deep-s1, fine-none-s1,
packet-packet_turbulence, packet-turbulence_control, packet-packet_null.
Run test_reduce.py to check the reference operators without fluid integration.
quality.py additionally requires saved full 3D snapshots and writes results/CASE-quality.json.
figures.py and history.py use the local results directory structure shown in their headers.
The two copied jet-check images in figures.py are earlier views of these same completed outputs; all new mechanism figures are generated from reduce.py products.
The archived Julia diagnostic modules document recorded component definitions; they are not launch scripts.
Native Float32 packet data are promoted to Float64 for analysis.
Snapshot velocities and mean profiles are single-seed results. Time averages have their intervals in captions.
Key caution: centered reference advection is not the actual WENO numerical tendency; differences appear in spatial remainders. Diagnostic closure is not convergence.
q sign is defined by derivatives in the gallery; the recorder's informal 'minus transverse vorticity' schema text is inaccurate under the standard right-handed y-vorticity convention.
