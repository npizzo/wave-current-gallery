from pathlib import Path
import os,json,csv,shutil
os.environ['MPLCONFIGDIR']='/tmp/matplotlib-mechanism-eval'
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from PIL import Image
ROOT=Path('outputs/mechanism-evaluation-20261107');R=ROOT/'results';P=ROOT/'gallery';P.mkdir(exist_ok=True)
names=['coarse-deep-s1','coarse-none-s1','fine-deep-s1','fine-none-s1','packet-packet_turbulence','packet-turbulence_control','packet-packet_null']
J={n:json.loads((R/(n+'.json')).read_text()) for n in names};D={n:np.load(R/(n+'.npz')) for n in names}
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','savefig.facecolor':'white'})
colors={'eddy':'#b33a3a','resolved2D':'#b33a3a','threeD':'#2166ac','vortex':'#be8900','numerical':'#777777','wave':'#be8900'}
u0=.000156359851299904;Te=113.09733552923254

def save(fig,name):
 fig.savefig(P/(name+'.png'),dpi=150);Image.open(P/(name+'.png')).convert('RGB').save(P/(name+'.webp'),quality=88,method=6)
 (P/(name+'.png')).unlink();plt.close(fig)

def copyfig(src,name):Image.open(src).convert('RGB').save(P/name,quality=88,method=6)
copyfig('outputs/jet-gate-20261107/refined-jet-check.png','jets-monochromatic.webp')
copyfig('outputs/jet-gate-20261107/packet-jet-check-zoom.png','jets-packet.webp')

def variance(d,tag='top025'):
 from_z=d['zf'][1:-1];Q=d['Q'];q2=d['q2']
 if Q.shape[1]==len(d['zf']):Q=Q[:,1:-1];q2=q2[:,1:-1]
 lo,hi={'top025':(-.25,0),'top0125':(-.125,0),'subsurface':(-.375,-.125)}[tag]
 edges=np.r_[from_z[0]-(from_z[1]-from_z[0])/2,(from_z[1:]+from_z[:-1])/2,from_z[-1]+(from_z[-1]-from_z[-2])/2]
 lo=max(lo,from_z[0]);hi=min(hi,from_z[-1]);wg=np.maximum(0,np.minimum(edges[1:],hi)-np.maximum(edges[:-1],lo));wg/=wg.sum()
 return (Q*Q)@wg-(Q@wg)**2

fig,ax=plt.subplots(2,2,figsize=(12,8),layout='constrained')
for n,style,label in [('fine-deep-s1','-','Refined'),('coarse-deep-s1','--','Coarse')]:
 d=D[n];zf=d['zf'];ax[0,0].plot(d['Q'][-1],zf,style,label=label)
 ax[1,0].plot(d['t'],variance(d)/variance(d)[0],style,label=label)
d=D['fine-deep-s1'];ax[0,0].plot(d['Q'][0],d['zf'],':',color='k',label='Initial')
for n,idx,style,label in [('packet-packet_turbulence',0,':','Initial'),('packet-packet_turbulence',-1,'-','Packet + turbulence'),('packet-turbulence_control',-1,'--','No-wave control')]:
 d=D[n];ax[0,1].plot(d['Q'][idx],d['zf'][1:-1],style,label=label)
for n,style,label in [('packet-packet_turbulence','-','Packet + turbulence'),('packet-turbulence_control','--','No-wave control')]:
 d=D[n];v=variance(d);ax[1,1].plot(d['t'],v/v[0],style,label=label)
for col,title in enumerate(['Monochromatic','Travelling packet']):
 ax[0,col].set(title=title,xlabel=r'$Q$ (s$^{-1}$)',ylabel='z (m)',ylim=(-.5 if col==0 else -.4,0));ax[0,col].legend(frameon=False,fontsize=9)
 ax[1,col].axhline(1,color='.6',lw=.8);ax[1,col].set(xlabel=r'$t/T_e$' if col==0 else 't (s)',ylabel=r'Upper-layer mean-PV variance / initial');ax[1,col].legend(frameon=False,fontsize=9)
save(fig,'pv-profiles')

fig,ax=plt.subplots(1,2,figsize=(12,5),layout='constrained')
d=D['fine-deep-s1'];z=d['z'];delta=d['U'][-1]-d['U'][0]
ax[0].plot(delta/u0,z,color='k',lw=2.5,label='Observed')
for k,label in [('eddy','2D eddy stress'),('threeD','3D stress'),('numerical','Spatial remainder')]:ax[0].plot(d['cum_'+k][-1]/u0,z,color=colors[k],label=label)
ax[0].set(xlabel=r'$\Delta U_L/u_0$',ylabel='z (m)',ylim=(-.5,0),title='Monochromatic · refined');ax[0].legend(frameon=False,fontsize=9)
pt,ct,pn=[D['packet-'+k] for k in ['packet_turbulence','turbulence_control','packet_null']];z=pt['z'];dz=np.diff(pt['zf'])
y=(pt['U'][-1]-pt['U'][0])-(ct['U'][-1]-ct['U'][0])-(pn['U'][-1]-pn['U'][0]);parts={k[4:]:pt[k]-ct[k]-pn[k] for k in pt.files if k.startswith('cum_')}
ax[1].plot(y*1000,z,color='k',lw=2.5,label='Observed paired response')
for k,label in [('threeD','3D stress'),('resolved2D','Resolved 2D stress'),('vortex','Stokes-vorticity term'),('numerical','Spatial remainder')]:ax[1].plot(parts[k]*1000,z,color=colors[k],label=label)
ax[1].set(xlabel=r'$\Delta U_E$ (mm s$^{-1}$)',ylabel='z (m)',ylim=(-.4,0),title='Packet · wave-induced response');ax[1].legend(frameon=False,fontsize=8)
for a in ax:a.axvline(0,color='.7',lw=.8)
save(fig,'momentum-budget')
paired_proj={k:float(np.sum(v*y*dz)/np.sum(y*y*dz)) for k,v in parts.items()}

fig,ax=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
for n,style,label in [('coarse-deep-s1','--','Coarse'),('fine-deep-s1','-','Refined')]:
 j=J[n];terms=['transport','threeD','spatial_residual'];vals=[j['PV_half_q2_budget']['top025'][k] for k in terms]
 ax[0].plot(np.arange(3),vals,style+'o',label=label)
ax[0].set(xticks=range(3),xticklabels=['Transport','3D stress','Spatial remainder'],ylabel=r'$\Delta\langle q^2/2\rangle$ (s$^{-2}$)',title='Monochromatic');ax[0].legend(frameon=False)
j=J['packet-packet_turbulence'];b=j['PV_half_q2_budget']['top025'];ks=['transport','threeD','numerical'];vals=[b[k] for k in ks]+[sum(b[k] for k in ['vortex','resolved_source','dt_stokes','background_change','pressure','roundoff'])]
ax[1].bar(range(4),vals,color=['#888','#2166ac','#b33a3a','#be8900']);ax[1].set(xticks=range(4),xticklabels=['Transport','3D stress','Spatial remainder','Other'],title='Travelling packet',ylabel=r'$\Delta\langle q^2/2\rangle$ (s$^{-2}$)')
for a in ax:a.axhline(0,color='k',lw=.7);a.ticklabel_format(axis='y',style='sci',scilimits=(0,0))
save(fig,'pv-budget')

fig,ax=plt.subplots(2,3,figsize=(14,7),layout='constrained')
for col,(n,label) in enumerate([('coarse-deep-s1','Coarse · waves'),('fine-deep-s1','Refined · waves'),('fine-none-s1','Refined · no waves')]):
 d=D[n];u=d['u_2000'];z=d['z'];sel=z>=-.25;nx=u.shape[1]
 im=ax[0,col].pcolormesh(np.arange(nx)/nx,z[sel],u[sel]/u0,cmap='RdBu_r',vmin=-1.5,vmax=1.5,shading='auto');ax[0,col].set(title=label,xlabel='x (m)',ylabel='z (m)')
 e=d['top025_E_2000'];sp=ax[1,col].pcolormesh(d['top025_kx'],d['top025_ell'],np.log10(np.maximum(e/e.sum(),1e-12)),cmap='magma',vmin=-6,vmax=-1,shading='nearest')
 ax[1,col].set(xlim=(-24,24),ylim=(-32,32),xlabel=r'$K/2\pi$ (cycles m$^{-1}$)',ylabel=r'$\ell/2\pi$ (cycles m$^{-1}$)')
fig.colorbar(im,ax=ax[0,:],label=r'$\overline{u_L}/u_0$',shrink=.8);fig.colorbar(sp,ax=ax[1,:],label=r'$\log_{10}$ normalized modal energy',shrink=.8)
save(fig,'spectra-monochromatic')

fig,ax=plt.subplots(2,2,figsize=(12,7),layout='constrained')
for col,(n,label) in enumerate([('packet-packet_turbulence','Packet · laminar response removed'),('packet-turbulence_control','No waves')]):
 d=D[n];u=d['spectrum_u_224'];z=d['z'];sel=z>=-.25;nx=u.shape[1]
 im=ax[0,col].pcolormesh(np.arange(nx)*12/nx,z[sel],1000*u[sel],cmap='RdBu_r',vmin=-15,vmax=15,shading='auto');ax[0,col].set(title=label,xlabel='x (m)',ylabel='z (m)')
 e=d['top025_E_224'];sp=ax[1,col].pcolormesh(d['top025_kx'],d['top025_ell'],np.log10(np.maximum(e/e.sum(),1e-12)),cmap='magma',vmin=-6,vmax=-1,shading='nearest')
 ax[1,col].set(xlim=(-24,24),ylim=(-32,32),xlabel=r'$K/2\pi$ (cycles m$^{-1}$)',ylabel=r'$\ell/2\pi$ (cycles m$^{-1}$)')
fig.colorbar(im,ax=ax[0,:],label=r'$\overline{u_E}-\overline{u_{E,\mathrm{null}}}$ (mm s$^{-1}$)',shrink=.8);fig.colorbar(sp,ax=ax[1,:],label=r'$\log_{10}$ normalized modal energy',shrink=.8)
save(fig,'spectra-packet')

fig,ax=plt.subplots(1,3,figsize=(14,4.2),layout='constrained');d=D['fine-deep-s1']
for a,tag,H in zip(ax,['top0125','top025','top05'],[.125,.25,.5]):
 e=d['avg_'+tag+'_100_200'];sp=a.pcolormesh(d[tag+'_kx'],d[tag+'_ell'],np.log10(np.maximum(e/e.sum(),1e-12)),cmap='magma',vmin=-6,vmax=-1,shading='nearest')
 a.set(title=f'H = {H:g} m',xlim=(-24,24),ylim=(-32,32),xlabel=r'$K/2\pi$ (cycles m$^{-1}$)',ylabel=r'$\ell/2\pi$ (cycles m$^{-1}$)')
fig.colorbar(sp,ax=ax,label=r'$\log_{10}$ normalized modal energy',shrink=.8)
save(fig,'window-sensitivity')

def timeavg(rows,lo,hi,col):
 rows=sorted([r for r in rows if lo-1e-6<=r[0]<=hi+1e-6],key=lambda r:r[0]);t=np.array([r[0] for r in rows]);v=np.array([r[col] for r in rows]);return float(np.trapezoid(v,t)/(t[-1]-t[0]))
fig,ax=plt.subplots(1,3,figsize=(15,4.4),layout='constrained');flux_summary={}
for n,style,label in [('coarse-deep-s1','--','Coarse waves'),('fine-deep-s1','-','Refined waves'),('fine-none-s1',':','Refined no waves')]:
 rows=[r for r in J[n]['horizontal_flux'] if r[1]=='top025'];ks=sorted(set(r[2] for r in rows if r[2]<=16));vals=[timeavg([r for r in rows if r[2]==k],100,200,3) for k in ks]
 ax[0].plot(ks,np.array(vals)*Te/u0**2,style,label=label);flux_summary[n]={'horizontal_Pi_100_200_top025':dict(zip(map(str,ks),vals))}
 g=D[n]['global_flux'];kk=np.arange(1,17);vv=[timeavg(g[g[:,1]==k].tolist(),100,200,2) for k in kk];ax[1].plot(kk,np.array(vv)*Te/u0**2,style,label=label)
for n,style,label in [('packet-packet_turbulence','-','Packet residual'),('packet-turbulence_control','--','No waves')]:
 rows=[r for r in J[n]['horizontal_flux'] if r[1]=='top025'];ks=sorted(set(r[2] for r in rows if r[2]<=16));vals=[timeavg([r for r in rows if r[2]==k],11.2,22.4,3) for k in ks]
 ax[2].plot(ks,np.array(vals)*1e8,style,label=label);flux_summary[n]={'horizontal_Pi_11p2_22p4_top025':dict(zip(map(str,ks),vals))}
for a in ax:a.axhline(0,color='.5',lw=.8);a.legend(frameon=False,fontsize=8)
ax[0].set(title='Monochromatic · horizontal filter',xlabel=r'$K_c/2\pi$ (cycles m$^{-1}$)',ylabel=r'$\Pi T_e/u_0^2$')
ax[1].set(title='Monochromatic · radial sum',xlabel=r'$\kappa_c/2\pi$ (cycles m$^{-1}$)',ylabel=r'$\Pi T_e/u_0^2$')
ax[2].set(title='Packet · horizontal self-transfer',xlabel=r'$K_c/2\pi$ (cycles m$^{-1}$)',ylabel=r'$\Pi$ ($10^{-8}$ m$^2$ s$^{-3}$)')
save(fig,'energy-transfer')

fig,ax=plt.subplots(1,2,figsize=(12,4.5),layout='constrained');phase_summary={}
for a,n,label in zip(ax,['fine-deep-s1','fine-none-s1'],['Deep-water waves','No waves']):
 d=D[n];omega=d['phase_omega'];order=np.argsort(omega);power=d['phase_power_z-0.07'];v=power/power.sum(axis=1)[:,None]
 im=a.pcolormesh(np.arange(1,17),omega[order],np.log10(np.maximum(v[:,order].T,1e-10)),cmap='magma',vmin=-5,vmax=-1,shading='nearest')
 a.axhline(0,color='cyan',lw=.8);a.set(title=label,xlabel=r'$K/2\pi$ (cycles m$^{-1}$)',ylabel=r'Intrinsic frequency (rad s$^{-1}$)',ylim=(-.06,.06))
 phase_summary[n]=[]
 for zz in [-.03,-.07,-.15,-.3]:
  rs=[r for r in J[n]['phase_test'] if abs(r['z']-zz)<.0025];weights=np.array([r['resolved_phase_power'] for r in rs]);f=np.array([r['negative_intrinsic_frequency_power_fraction'] for r in rs]);phase_summary[n].append({'z':rs[0]['z'],'negative_fraction':float(np.sum(weights*f)/weights.sum()),'Qz':rs[0]['Qz_late_mean'],'Qz_negative_time_fraction':rs[0]['Qz_negative_time_fraction']})
fig.colorbar(im,ax=ax,label=r'$\log_{10}$ normalized power',shrink=.8)
save(fig,'wave-phase')

# Compact derived tables; full simulation fields are not included in the public package.
with (P/'momentum-contributions.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['case','component','projected_final_profile_fraction','mean_energy_increment_m2_s2'])
 for n in names:
  if n=='packet-packet_null':continue
  for k,v in J[n]['momentum_projected_fraction'].items():w.writerow([n,k,v,J[n]['mean_energy_increment_by_component'].get(k,'')])
 for k,v in paired_proj.items():w.writerow(['packet_wave_induced_difference',k,v,'not an energy fraction'])
with (P/'pv-summary.csv').open('w') as f:
 w=csv.writer(f);keys=['mean_profile_variance_ratio','total_spatial_variance_ratio','gradient_rms_ratio','flat_fraction_final_relative_initial_gradient','flat_fraction_late_mean'];w.writerow(['case','layer']+keys)
 for n in names:
  if n=='packet-packet_null':continue
  for tag,v in J[n]['pv'].items():w.writerow([n,tag]+[v.get(k) for k in keys])
with (P/'pv-budgets.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['case','layer','component','half_q2_increment_s-2'])
 for n in names:
  for tag,v in J[n]['PV_half_q2_budget'].items():
   for k,val in v.items():w.writerow([n,tag,k,val])
with (P/'spectral-summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['case','window','late_interval','horizontal_sector_fraction_4to16','K0_fraction','vertical_bin_spacing_cycles_m'])
 for n in names:
  if n=='packet-packet_null':continue
  late=(100,200) if not n.startswith('packet') else (11.2,22.4)
  for tag in sorted(set(r['window'] for r in J[n]['spectral_metrics'])):
   rs=[r for r in J[n]['spectral_metrics'] if r['window']==tag and late[0]-1e-6<=r['t']<=late[1]+1e-6];ts=np.array([r['t'] for r in rs]);order=np.argsort(ts);ts=ts[order]
   def avg(key):return np.trapezoid(np.array([r[key] for r in rs])[order],ts)/(ts[-1]-ts[0])
   w.writerow([n,tag,str(late),avg('angular_fraction_4_16'),avg('jet_K0_fraction'),rs[0]['vertical_bin_spacing_cycles_m']])
(P/'phase-summary.json').write_text(json.dumps(phase_summary,indent=2)+'\n');(P/'transfer-summary.json').write_text(json.dumps(flux_summary,indent=2)+'\n')
(P/'paired-momentum.json').write_text(json.dumps({'projection_fractions':paired_proj,'peak_wave_induced_current_mm_s':float(y.min()*1000),'definition':'Difference of final-minus-initial Eulerian mean profiles: turbulent packet minus no-wave turbulence minus packet-only. Component fractions are projections onto this observed response, not fractions of the total stress norm.'},indent=2)+'\n')
print('Figures and compact supporting tables created in',P)
for f in sorted(P.glob('*.webp')):print(f.name,round(f.stat().st_size/1024),'KiB')
