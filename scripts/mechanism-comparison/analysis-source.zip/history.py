from pathlib import Path
import os,json,csv
os.environ['MPLCONFIGDIR']='/tmp/matplotlib-mechanism-eval'
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
R=Path('outputs/mechanism-evaluation-20261107/results');P=R.parent/'gallery';Te=113.09733552923254;u0=.000156359851299904
fig,ax=plt.subplots(2,2,figsize=(12,7),layout='constrained');rows=[]
for n,style,label in [('coarse-deep-s1','--','Coarse waves'),('fine-deep-s1','-','Refined waves'),('fine-none-s1',':','Refined no waves')]:
 d=np.load(R/(n+'.npz'));j=json.loads((R/(n+'.json')).read_text());E=np.mean(d['U']**2,axis=1)/2
 ax[0,0].plot(d['t'],E/u0**2,style,label=label)
 h=np.array([[r[0],r[3]] for r in j['horizontal_flux'] if r[1]=='top025' and r[2]==2]);ax[1,0].plot(h[:,0],h[:,1]*Te/u0**2,style)
 for t,e in zip(d['t'],E):rows.append([n,t,'mean_Lagrangian_energy',e,'m2 s-2'])
 for t,v in h:rows.append([n,t,'upper025_Pi_horizontal_cutoff2',v,'m2 s-3'])
pt=np.load(R/'packet-packet_turbulence.npz');ct=np.load(R/'packet-turbulence_control.npz');pn=np.load(R/'packet-packet_null.npz');t=pt['t'];dz=np.diff(pt['zf']);H=dz.sum()
for v,label in [('U','Eulerian mean'),('UL','Lagrangian mean')]:
 E=pt[v]**2@dz/(2*H);ax[0,1].plot(t,(E-E[0])*1e6,label=label)
 for tt,ee in zip(t,E-E[0]):rows.append(['packet-packet_turbulence',tt,'change_mean_'+v+'_energy',ee,'m2 s-2'])
y=(pt['U']-pt['U'][0])-(ct['U']-ct['U'][0])-(pn['U']-pn['U'][0]);sel=pt['z']>=-.02
ax[1,1].plot(t,y[:,sel]@dz[sel]/dz[sel].sum()*1000,color='#2166ac')
ax[0,0].set(xlabel=r'$t/T_e$',ylabel=r'$E_{\rm mean}/u_0^2$',title='Monochromatic');ax[0,0].legend(frameon=False)
ax[1,0].set(xlabel=r'$t/T_e$',ylabel=r'$\Pi T_e/u_0^2$',title=r'Upper 0.25 m · $K_c/2\pi=2$ m$^{-1}$')
ax[0,1].set(xlabel='t (s)',ylabel=r'$\Delta E_{\rm mean}$ ($10^{-6}$ m$^2$ s$^{-2}$)',title='Packet + turbulence');ax[0,1].legend(frameon=False)
ax[1,1].set(xlabel='t (s)',ylabel=r'$\Delta U_E$ (mm s$^{-1}$)',title='Wave-induced response · upper 0.02 m')
for a in ax.flat:a.axhline(0,color='.7',lw=.7);a.spines[['top','right']].set_visible(False)
fig.savefig(P/'formation-history.png',dpi=150);Image.open(P/'formation-history.png').convert('RGB').save(P/'formation-history.webp',quality=88);(P/'formation-history.png').unlink()
with (P/'formation-history.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['case','time_Te_monochromatic_or_seconds_packet','quantity','value','units']);w.writerows(rows)
quality={p.name.replace('-quality.json',''):json.loads(p.read_text()) for p in R.glob('*-quality.json')}
for v in quality.values():v.pop('runtime_seconds',None)
(P/'resolution-and-phase-checks.json').write_text(json.dumps(quality,indent=2)+'\n')
for n in ['coarse-deep-s1','fine-deep-s1','packet-packet_turbulence']:
 q=quality[n];print(n,{k:v for k,v in q.items() if 'fraction' in k})
