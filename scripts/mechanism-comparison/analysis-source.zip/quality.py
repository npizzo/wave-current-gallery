"""Full-state grid-scale energy and early intrinsic-frequency checks; no simulation."""
import pathlib,numpy as np,h5py,json,argparse,time
from scipy.fft import rfft,fft,dct,dst
from reduce import BASE
p=argparse.ArgumentParser();p.add_argument('name');a=p.parse_args();name=a.name;out={};t0=time.time()
if not name.startswith('packet-'):
 root=BASE/'jet3d-mechanisms-20261107-relaunch/data'/name;n=512 if name.startswith('fine') else 256;nz=nx=n;ny=n//2
 tail=total=0.;components={}
 with h5py.File(root/'snapshot_t0200.0.jld2') as f:
  for key in ['u','v','w']:
   v=f[key][:].astype(float)
   if key=='w':v=v[1:-1]
   hz=dct(v,type=2,axis=0,norm='ortho') if key!='w' else dst(v,type=1,axis=0,norm='ortho')
   hz=fft(rfft(hz,axis=2,norm='ortho'),axis=1,norm='ortho');en=(abs(hz)**2)
   mult=np.ones(nx//2+1)*2;mult[[0,-1]]=1;en*=mult[None,None,:]
   maskx=np.arange(nx//2+1)>.8*nx/2;masky=abs(np.fft.fftfreq(ny)*ny)>.8*ny/2
   iz=np.arange(nz) if key!='w' else np.arange(1,nz)
   mask=(iz[:,None,None]>.8*nz)|(masky[None,:,None])|(maskx[None,None,:])
   e=float(en.sum());et=float(en[mask].sum());components[key]={'energy_norm':e,'tail_fraction':et/e};total+=e;tail+=et
   assert abs(e-np.sum(v*v))/e<1e-12
 out['full_3D_energy_above_80pct_coordinate_Nyquist_fraction']=tail/total;out['components']=components
 # Early wave phase check, while jets are developing. Local U(t,z) is demodulated.
 pt=np.genfromtxt(root/'phase-times.csv',delimiter=',',names=True);nk=33;rec=nk*(2*nz+1)
 ph=np.memmap(root/'phase.bin',dtype='<c8',mode='r',shape=(len(pt),rec));nc=14*nz+10
 b=np.memmap(root/'budgets.bin',dtype='<f8',mode='r',shape=((root/'budgets.bin').stat().st_size//8//nc,nc));Te=113.09733552923254
 tu=np.arange(10,50,.05);dt=.05*Te;om=-2*np.pi*np.fft.fftfreq(len(tu),dt);resolved=abs(om)>=4*np.pi/(40*Te)
 zc=-1+(np.arange(nz)+.5)/nz;zf=np.linspace(-1,0,nz+1);phase=[]
 for zz in [-.03,-.07,-.15,-.3]:
  iz=int(np.argmin(abs(zf-zz)));jc=max(0,iz-1);U=np.interp(tu,b[:,0]/Te,b[:,2+jc]);rows=[]
  for mode in range(1,17):
   v=ph[:,nk*nz+iz*nk+mode];sig=np.interp(tu,pt['t']/Te,v.real)+1j*np.interp(tu,pt['t']/Te,v.imag)
   sig*=np.exp(1j*2*np.pi*mode*np.cumsum(U)*dt);sig-=sig.mean();power=abs(np.fft.fft(sig*np.hanning(len(sig))))**2
   rows.append([power[(om<0)&resolved].sum(),power[resolved].sum(),power.sum()])
  rows=np.array(rows);phase.append({'z':float(zf[iz]),'negative_intrinsic_frequency_power_fraction':float(rows[:,0].sum()/rows[:,1].sum()),'resolved_power_fraction':float(rows[:,1].sum()/rows[:,2].sum())})
 out['early_phase_10_50_Te']=phase
else:
 member=name[len('packet-'):];seed='quiescent' if member=='packet_null' else 'seed_0001';root=BASE/f'case1d-periodic-mechanisms-20261107/data/campaign/case_1D/M2/{member}/{seed}_dt0.020'
 with h5py.File(root/'mechanisms/grid.jld2') as f:z=f['zc'][:];zf=f['zf'][:]
 with h5py.File(root/'mechanisms/dense/frame_0224.jld2') as f:us=f['us'][:];ws=f['ws'][:]
 total=tail=0.;components={}
 with h5py.File(root/'mechanism_snapshots.jld2') as f:
  key=max(f['timeseries/t'].keys(),key=int);out['snapshot_time']=float(f['timeseries/t/'+key][()])
  for component in ['u','v','w']:
   ds=f['timeseries/'+component+'/'+key];nz,ny,nx=ds.shape;weights=np.diff(zf) if component!='w' else np.r_[np.diff(zf)[0]/2,np.diff(z),np.diff(zf)[-1]/2]
   ec=tc=0.;maskx=np.arange(nx//2+1)>.8*nx/2;masky=abs(np.fft.fftfreq(ny)*ny)>.8*ny/2;mask=masky[:,None]|maskx[None,:]
   mult=np.ones(nx//2+1)*2;mult[[0,-1]]=1
   for lo in range(0,nz,16):
    hi=min(nz,lo+16);v=ds[lo:hi].astype(float)
    if component=='u':v-=us[lo:hi,None,:]
    if component=='w':v-=ws[lo:hi,None,:]
    h=fft(rfft(v,axis=2,norm='ortho'),axis=1,norm='ortho');e=abs(h)**2*mult[None,None,:];e*=weights[lo:hi,None,None]
    ec+=e.sum();tc+=e[:,mask].sum()
   components[component]={'horizontal_tail_fraction':float(tc/ec)};total+=ec;tail+=tc
 out['full_3D_Eulerian_energy_above_80pct_horizontal_Nyquist_fraction']=float(tail/total);out['components']=components
 out['vertical_tail']='Not assigned a uniform-grid Fourier Nyquist measure on the stretched vertical grid.'
out['runtime_seconds']=time.time()-t0
pathlib.Path('results').mkdir(exist_ok=True)
pathlib.Path('results',name+'-quality.json').write_text(json.dumps(out,indent=2)+'\n');print(name,json.dumps(out),flush=True)
