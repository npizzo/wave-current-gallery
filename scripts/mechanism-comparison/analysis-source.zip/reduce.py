"""Read-only mechanism audit of completed 3D monochromatic and packet runs."""
from pathlib import Path
import numpy as np,h5py,json,time,argparse
from scipy.fft import fft2,fftshift,fftfreq,rfft,dct,dst
from scipy.signal import periodogram
import os
BASE=Path(os.environ.get('WAVE_ARCHIVE_ROOT', '/path/to/archive'))
LAYERS={'top0125':(-.125,0),'top025':(-.25,0),'top05':(-.5,0),'subsurface':(-.375,-.125)}

def dec(f,a):
 if isinstance(a,h5py.Reference):return dec(f,f[a][()])
 if isinstance(a,bytes):return a.decode()
 if isinstance(a,np.void) and a.dtype.names:
  if a.dtype.names==('kvvec',):
   return {str(dec(f,p['first'])):dec(f,p['second']) for ref in f[a['kvvec']][:] for p in [f[ref][()]]}
  return {n:dec(f,a[n]) for n in a.dtype.names}
 return a

def deriv(a,z):return np.gradient(a,z,axis=0,edge_order=2)
def nzprofile(A):return np.mean(A,axis=-1)
def weight(z,lo,hi):
 edges=np.r_[z[0]-(z[1]-z[0])/2,(z[1:]+z[:-1])/2,z[-1]+(z[-1]-z[-2])/2]
 w=np.maximum(0,np.minimum(edges[1:],hi)-np.maximum(edges[:-1],lo));return w/w.sum()
def summary_pv(Q,q2,z,t):
 out={};grad=np.gradient(Q,z,axis=1,edge_order=2)
 for tag,(lo,hi) in LAYERS.items():
  lo=max(lo,float(z[0]));hi=min(hi,float(z[-1]));wg=weight(z,lo,hi)
  mq=Q@wg;var=(Q*Q)@wg-mq*mq;total=q2@wg-mq*mq
  base=grad[0];floor=max(np.max(abs(base))*1e-4,1e-10)
  valid=(wg>0)&(abs(base)>floor)
  flat=(abs(grad)<.2*abs(base))[...,valid]@wg[valid]/wg[valid].sum() if valid.any() else np.full(len(t),np.nan)
  out[tag]={'mean_profile_variance_initial':float(var[0]),'mean_profile_variance_final':float(var[-1]),'mean_profile_variance_ratio':float(var[-1]/var[0]) if var[0]>1e-20 else None,
   'total_spatial_variance_initial':float(total[0]),'total_spatial_variance_final':float(total[-1]),'total_spatial_variance_ratio':float(total[-1]/max(total[0],1e-30)),
   'gradient_rms_ratio':float(np.sqrt((grad[-1]**2)@wg/((base**2)@wg))) if (base**2)@wg>1e-20 else None,
   'flat_fraction_final_relative_initial_gradient':float(flat[-1]) if np.isfinite(flat[-1]) else None,'flat_fraction_late_mean':float(np.mean(flat[t>=.75*t[-1]])) if np.all(np.isfinite(flat)) else None}
 return out

def products(u,w,z,zf):
 alpha=((zf[1:-1]-z[:-1])/np.diff(z))[:,None]
 uf=(1-alpha)*u[:-1]+alpha*u[1:]
 uw=np.zeros_like(w);uw[1:-1]=uf*(w[1:-1]+np.roll(w[1:-1],1,axis=1))/2
 return ((u+np.roll(u,-1,axis=1))/2)**2,uw,((w[:-1]+w[1:])/2)**2

def force(u,w,z,zf,dx):
 uu,uw,ww=products(u,w,z,zf)
 fu=-(uu-np.roll(uu,1,axis=1))/dx-np.diff(uw,axis=0)/np.diff(zf)[:,None]
 fw=np.zeros_like(w);fw[1:-1]=-(np.roll(uw[1:-1],-1,axis=1)-uw[1:-1])/dx-np.diff(ww,axis=0)/np.diff(z)[:,None]
 return fu,fw

def horizontal_flux(u,w,z,zf,dx,cutoffs):
 nx=u.shape[1];kx=np.fft.rfftfreq(nx,dx);H=np.fft.rfft
 uu,uw,ww=products(u,w,z,zf)
 hu,hw,huu,huw,hww=[H(a,axis=1) for a in (u,w,uu,uw,ww)]
 result=[]
 for kc in cutoffs:
  mask=(kx<=kc+1e-10)[None,:]
  def filt(h):return np.fft.irfft(h*mask,n=nx,axis=1)
  ub,wb=filt(hu),filt(hw);puu,puw,pww=products(ub,wb,z,zf)
  tuu,tuw,tww=filt(huu)-puu,filt(huw)-puw,filt(hww)-pww
  normal=-tuu*(np.roll(ub,-1,axis=1)-ub)/dx-tww*np.diff(wb,axis=0)/np.diff(zf)[:,None]
  shear=np.zeros_like(w);shear[1:-1]=-tuw[1:-1]*(np.diff(ub,axis=0)/np.diff(z)[:,None]+(wb[1:-1]-np.roll(wb[1:-1],1,axis=1))/dx)
  # Native dual-cell weighting, partitioned equally between adjoining cells.
  weighted_shear=np.zeros_like(normal)
  weighted_shear[:-1]+=shear[1:-1]*np.diff(z)[:,None]/2
  weighted_shear[1:]+=shear[1:-1]*np.diff(z)[:,None]/2
  result.append(np.mean(normal+weighted_shear/np.diff(zf)[:,None],axis=1))
 return np.array(result)

def local_spectrum(u,w,z,zf,lx,lo,hi,uniform_n=None):
 uc=(u+np.roll(u,-1,axis=1))/2;wc=(w[:-1]+w[1:])/2
 sel=(z>=lo)&(z<=hi);zz=z[sel]
 # Packet grid is stretched: interpolate to a documented uniform physical-depth grid.
 if uniform_n is not None:
  zz=np.linspace(lo,hi,uniform_n,endpoint=False)+(hi-lo)/uniform_n/2
  a=np.array([np.interp(zz,z,uc[:,i]) for i in range(uc.shape[1])]).T
  b=np.array([np.interp(zz,z,wc[:,i]) for i in range(wc.shape[1])]).T
 else:a,b=uc[sel],wc[sel]
 nz,nx=a.shape;dz=zz[1]-zz[0];tap=np.hanning(nz)[:,None];norm=(nx*nz)**2*np.mean(tap*tap)
 hu,hv=fft2(tap*a),fft2(tap*b)
 en=fftshift((abs(hu)**2+abs(hv)**2)/2/norm)
 stress=fftshift(np.real(hu.conj()*hv)/norm)
 kx=fftshift(fftfreq(nx,lx/nx));ell=fftshift(fftfreq(nz,dz))
 kk,ll=np.meshgrid(kx,ell);rr=np.hypot(kk,ll)
 metrics={'vertical_bin_spacing_cycles_m':float(1/(nz*dz)),'jet_K0_fraction':float(en[:,kx==0].sum()/max(en.sum(),1e-30)),
  'resolved_stress_tapered':float(np.mean(tap*tap*a*b)/np.mean(tap*tap)), 'cospectrum_sum':float(stress.sum())}
 for low,high in [(2,8),(4,16),(8,24)]:
  mask=(rr>=low)&(rr<high)&(kk!=0);horizontal=mask&(abs(kk)>=np.sqrt(3)*abs(ll))
  metrics[f'angular_fraction_{low}_{high}']=float(en[horizontal].sum()/max(en[mask].sum(),1e-30))
  metrics[f'angular_bin_fraction_{low}_{high}']=float(horizontal.sum()/max(mask.sum(),1))
  metrics[f'annulus_energy_{low}_{high}']=float(en[mask].sum())
 ix=abs(kx)<=32;iz=abs(ell)<=48
 return en[np.ix_(iz,ix)],stress[np.ix_(iz,ix)],kx[ix],ell[iz],metrics

def native_spectrum(u,w):
 nx,nz=u.shape[1],u.shape[0]
 hu=dct(rfft(u,axis=1,norm='ortho'),type=2,axis=0,norm='ortho')
 hw=np.zeros_like(hu);hw[1:]=dst(rfft(w[1:-1],axis=1,norm='ortho'),type=1,axis=0,norm='ortho')
 mult=np.ones(nx//2+1)*2;mult[[0,-1]]=1
 return hu,hw,mult/(nx*nz)

def mono(name,out):
 start=time.time();root=BASE/'jet3d-mechanisms-20261107-relaunch/data'/name
 nz=512 if name.startswith('fine') else 256;nx=nz;dx=dz=1/nz;Te=113.09733552923254;u0=.000156359851299904
 z=-1+(np.arange(nz)+.5)*dz;zf=np.linspace(-1,0,nz+1);waves='deep' in name
 ncols=14*nz+10;size=(root/'budgets.bin').stat().st_size;assert size%(8*ncols)==0
 b=np.memmap(root/'budgets.bin',dtype='<f8',mode='r',shape=(size//8//ncols,ncols));tt=b[:,0]/Te
 idx=np.unique(np.r_[0,np.searchsorted(tt,np.arange(.1,200.0001,.1)),len(tt)-1]);idx=np.minimum(idx,len(tt)-1)
 off=2;columns={}
 for key,n in [('U',nz),('Q',nz+1),('q2',nz+1),('Rphysical',nz+1),('R2',nz+1),('Rnative',nz+1)]:columns[key]=slice(off,off+n);off+=n
 terms=['eddy','mean','threeD','wave','numerical'];pvterms=['transport','threeD','spatial_residual']
 for k in terms:columns['cum_'+k]=slice(off,off+nz);off+=nz
 for k in pvterms:columns['pv_'+k]=slice(off,off+nz+1);off+=nz+1
 assert off==ncols
 D={'z':z,'zf':zf,'t':np.asarray(tt[idx]),'Te':np.array(Te),'u0':np.array(u0)}
 for k,s in columns.items():D[k]=np.asarray(b[idx,s])
 U0,U1=D['U'][0],D['U'][-1];dU=U1-U0
 projected={k:float(np.dot(D['cum_'+k][-1],dU)/np.dot(dU,dU)) for k in terms}
 error=float(np.linalg.norm(dU-sum(D['cum_'+k][-1] for k in terms))/np.linalg.norm(dU))
 # Exact discrete endpoint allocation of mean-flow kinetic energy, using every recorded full step.
 work={k:0. for k in terms}
 for j in range(1,len(tt),256):
  sl=slice(j,min(j+256,len(tt)));prev=slice(j-1,min(j+256,len(tt))-1)
  mid=(np.asarray(b[sl,columns['U']])+np.asarray(b[prev,columns['U']]))/2
  for k in terms:work[k]+=float(np.sum(mid*(b[sl,columns['cum_'+k]]-b[prev,columns['cum_'+k]]))*dz)
 deltaE=float(np.mean(U1**2-U0**2)/2)
 pv=summary_pv(D['Q'][:,1:-1],D['q2'][:,1:-1],zf[1:-1],D['t'])
 # High-resolution budget is an arithmetic identity; separate physical reference and residual.
 pvbudget={tag:{k:float(weight(zf[1:-1],max(lo,zf[1]),min(hi,zf[-2]))@D['pv_'+k][-1,1:-1]) for k in pvterms} for tag,(lo,hi) in LAYERS.items()}
 for tag,(lo,hi) in LAYERS.items():pvbudget[tag]['observed_half_q2_change']=float(weight(zf[1:-1],max(lo,zf[1]),min(hi,zf[-2]))@(D['q2'][-1,1:-1]-D['q2'][0,1:-1])/2)
 stages=[(0,10),(10,25),(25,50),(50,100),(100,200)];samples=list(range(0,2001,50));sums={};counts={};specmetrics=[];globalflux=[];hflux=[]
 cutoffs=np.array([0,1,2,4,8,12,16,24,32,48,64,96]);D['horizontal_cutoffs']=cutoffs
 for n in samples:
  with h5py.File(root/'dense'/f'frame_{n:05d}.jld2') as f:
   A=f['packet'][:].astype(float);u=A[0,:-1];w=A[2];t=float(f['t'][()])/Te
   if n in (0,100,250,500,1000,1500,2000):D[f'u_{n}']=u;D[f'q_{n}']=f['q'][:];D[f'w_{n}']=w
   # Full-domain native-basis conservative-reference transfer, with K=0 tracked separately.
   fu,fw=force(u,w,z,zf,dx);ue=u-u.mean(1)[:,None];eeu,eew=force(ue,w,z,zf,dx)
   hu,hw,mult=native_spectrum(u,w);en=(abs(hu)**2+abs(hw)**2)*mult/2
   pu,pw,_=native_spectrum(fu,fw);eu,ew,_=native_spectrum(eeu,eew)
   T=np.real(hu.conj()*pu+hw.conj()*pw)*mult;Tee=np.real(hu.conj()*eu+hw.conj()*ew)*mult
   K,L=np.meshgrid(np.arange(nx//2+1),np.arange(nz)/2);radius=np.hypot(K,L)
   for kc in range(1,25):
    mask=radius<=kc
    globalflux.append([t,kc,-T[mask].sum(),-Tee[mask].sum(),Tee[:,0].sum(),T.sum(),en[(K>.8*nx/2)|(L>.8*nz/2)].sum()/en.sum()])
   pif=horizontal_flux(u,w,z,zf,dx,cutoffs)
   for tag,(lo,hi) in LAYERS.items():
    wg=weight(z,lo,hi)
    for kc,val in zip(cutoffs,pif@wg):hflux.append([t,tag,float(kc),float(val)])
    enlocal,stress,kx,ell,metrics=local_spectrum(u,w,z,zf,1,lo,hi)
    specmetrics.append({'t':t,'window':tag,**metrics})
    D[tag+'_kx']=kx;D[tag+'_ell']=ell
    if n in (0,500,1000,2000):D[f'{tag}_E_{n}']=enlocal;D[f'{tag}_stress_{n}']=stress
    for low,high in stages:
     if low-1e-6<=t<=high+1e-6:
      key=f'{tag}_{low}_{high}';wt=.5 if abs(t-low)<1e-6 or abs(t-high)<1e-6 else 1
      sums[key]=sums.get(key,0)+wt*enlocal;counts[key]=counts.get(key,0)+wt
  if n%500==0:print(name,'spectra',n/10,'elapsed',round(time.time()-start),flush=True)
 for key,val in sums.items():D['avg_'+key]=val/counts[key]
 D['global_flux']=np.array(globalflux)
 # Low-mode phase-sign diagnostic: remove actual time-dependent mean advection at each depth.
 # This checks propagation sign, not independent group velocity or radiation from a source.
 pt=np.genfromtxt(root/'phase-times.csv',names=True,delimiter=',');nt=len(pt);nk=33;record=nk*(2*nz+1)
 ph=np.memmap(root/'phase.bin',dtype='<c8',mode='r',shape=(nt,record));times=pt['t']/Te
 phase_results=[];D['phase_depths']=np.array([-.03,-.07,-.15,-.3])
 tu=np.arange(100,200,.05);omega=-2*np.pi*np.fft.fftfreq(len(tu),.05*Te)
 for level in D['phase_depths']:
  iz=int(np.argmin(abs(zf-level)));jcenter=max(0,min(nz-1,iz-1));U=np.interp(tu,D['t'],D['U'][:,jcenter]);Qz=np.gradient(D['Q'],zf,axis=1)[:,iz]
  Qzlate=float(np.mean(Qz[D['t']>=100]));ps=[]
  for mode in range(1,17):
   series=ph[:,nk*nz+iz*nk+mode]
   signal=np.interp(tu,times,series.real)+1j*np.interp(tu,times,series.imag)
   signal*=np.exp(1j*(2*np.pi*mode)*np.cumsum(U)*(.05*Te))
   signal-=signal.mean();power=abs(np.fft.fft(signal*np.hanning(len(signal))))**2
   # Intrinsic frequencies below two bins cannot discriminate propagation sign.
   resolved=abs(omega)>=2*2*np.pi/(100*Te)
   negative=power[(omega<0)&resolved].sum()/max(power[resolved].sum(),1e-100)
   phase_results.append({'z':float(zf[iz]),'K_cycles_m':mode,'Qz_late_mean':Qzlate,'Qz_negative_time_fraction':float(np.mean(Qz[D['t']>=100]<0)),
    'negative_intrinsic_frequency_power_fraction':float(negative),'resolved_phase_power':float(power[resolved].sum()),'unresolved_frequency_power_fraction':float(power[~resolved].sum()/max(power.sum(),1e-100))})
   ps.append(power)
  D[f'phase_power_z{level}']=np.array(ps)
 D['phase_omega']=omega
 info={'name':name,'pv':pv,'PV_half_q2_budget':pvbudget,'momentum_projected_fraction':projected,'momentum_reconstruction_relative_error':error,
  'mean_energy_change':deltaE,'mean_energy_increment_by_component':work,'mean_energy_fraction_by_component':{k:v/deltaE for k,v in work.items()},
  'spectral_metrics':specmetrics,'horizontal_flux':hflux,'phase_test':phase_results,'runtime_seconds':time.time()-start,
  'global_flux_columns':['t_Te','radius_cycles_m','Pi_resolved2D','Pi_eddy_eddy','eddy_work_on_K0','net_centered_advection_work','near_grid_reduced_energy_fraction'],
  'source':str(root),'meaning':'Read-only analysis; spectra concern the transverse-mean x-z velocity, not all 3D energy.'}
 out.mkdir(exist_ok=True,parents=True);np.savez_compressed(out/(name+'.npz'),**D);(out/(name+'.json')).write_text(json.dumps(info,indent=2)+'\n')
 print('DONE',name,round(time.time()-start),flush=True)

def packet(name,out):
 start=time.time();member=name.replace('packet-','',1);seed='quiescent' if member=='packet_null' else 'seed_0001'
 root=BASE/f'case1d-periodic-mechanisms-20261107/data/campaign/case_1D/M2/{member}/{seed}_dt0.020/mechanisms'
 with h5py.File(root/'grid.jld2') as f:z=f['zc'][:].astype(float);zf=f['zf'][:].astype(float)
 nx=1536;nz=len(z);dx=12/nx;dz=np.diff(zf);qz=zf[1:-1];dc=np.diff(z)
 D={'z':z,'zf':zf};hist={k:[] for k in ['t','U','UL','Q','q2','U_fov','Ulocal','Qlocal','R3','R2','wave_shear_mean']}
 cum={};cumlocal={};cumpv={};work={};lastU=None;lastE=None;lastcum=None;errors=[];specmetrics=[];hflux=[];sums={};counts={}
 cutoffs=np.array([0,1/12,.25,.5,1,2,4,8,12,16,24]);D['horizontal_cutoffs']=cutoffs
 x=np.arange(nx)*dx;fov=(x>=5)&(x<=7)
 stages=[(0,5.6),(5.6,11.2),(11.2,16.8),(16.8,22.4)]
 for j,path in enumerate(sorted((root/'dense').glob('*.jld2'))):
  with h5py.File(path) as f:
   A=f['planes'][:].astype(float);us=f['us'][:].astype(float);ws=f['ws'][:].astype(float)
   u=A[0,:-1];w=A[2];ue=u-us;we=w-ws;t=float(f['t'][()]);q=f['q'][:].astype(float)
   current=dec(f,f['cumulative_U'][()]);pvcur=dec(f,f['cumulative_q_half2'][()])
   impulses=f['interval_impulses'][()]
   # Decode only the along-wave impulse component; preserve local pressure and explicit wave effects.
   local={}
   for ref in f[impulses['kvvec']][:]:
    pair=f[ref][()];key=dec(f,pair['first']);local[key]=f[pair['second']['u']][:].astype(float)
   if not cumlocal:cumlocal={k:np.zeros_like(v) for k,v in local.items()}
   for k,v in local.items():cumlocal[k]+=v
   U=ue.mean(1);UL=u.mean(1)
   if lastU is not None:
    for k,v in current.items():work[k]=work.get(k,0)+float(np.sum((U+lastU)/2*(v-lastcum[k])*dz)/dz.sum())
    # Exact Eulerian prescribed-Stokes correction to mean momentum and kinetic energy.
    change_s=(us.mean(1)-lasts)
    work['stokes_subtraction']=work.get('stokes_subtraction',0)-float(np.sum((U+lastU)/2*change_s*dz)/dz.sum())
   else:initialU=U.copy();initialUL=UL.copy();initialE=ue.copy();initial_s=us.copy();initial_q=q.copy()
   lastU=U.copy();lastcum=current;lasts=us.mean(1)
   alpha=((zf[1:-1]-z[:-1])/np.diff(z))[:,None];uf=(1-alpha)*u[:-1]+alpha*u[1:]
   r2=np.zeros_like(w);r2[1:-1]=uf*(w[1:-1]+np.roll(w[1:-1],1,axis=1))/2
   R3=(A[9]-r2).mean(1);r2E=products(ue,we,z,zf)[1].mean(1)
   for k,v in [('t',t),('U',U),('UL',UL),('Q',q.mean(1)),('q2',(q*q).mean(1)),('U_fov',ue[:,fov].mean(1)),('Ulocal',ue[:,::8]),('Qlocal',q[:,::8]),('R3',R3),('R2',r2E),('wave_shear_mean',np.gradient(us.mean(1),z))]:hist[k].append(v)
   if j in [0,56,112,168,224,225]:
    D[f'u_{j}']=ue;D[f'w_{j}']=we;D[f'q_{j}']=q;D[f'us_{j}']=us
   if j%14==0 or j==225:
    su,sw=ue,we
    if member=='packet_turbulence':
     null=BASE/'case1d-periodic-mechanisms-20261107/data/campaign/case_1D/M2/packet_null/quiescent_dt0.020/mechanisms/dense'/path.name
     with h5py.File(null) as nf:
      su=ue-(nf['planes'][0,:-1,:].astype(float)-nf['us'][:])
      sw=we-(nf['planes'][2,:,:].astype(float)-nf['ws'][:])
    if j in (0,112,168,224,225):D[f'spectrum_u_{j}']=su;D[f'spectrum_w_{j}']=sw
    for tag,(lo,hi) in {'top0125':(-.125,0),'top025':(-.25,0),'full':(-.4,0)}.items():
     en,stress,kx,ell,met=local_spectrum(su,sw,z,zf,12,lo,hi,uniform_n=64 if tag=='top0125' else 128)
     specmetrics.append({'t':t,'window':tag,**met});D[tag+'_kx']=kx;D[tag+'_ell']=ell
     if j in (0,112,168,224,225):D[f'{tag}_E_{j}']=en;D[f'{tag}_stress_{j}']=stress
     for low,high in stages:
      if low-1e-6<=t<=high+1e-6 and j!=225:
       key=f'{tag}_{low}_{high}';wt=.5 if abs(t-low)<1e-5 or abs(t-high)<1e-5 else 1
       sums[key]=sums.get(key,0)+wt*en;counts[key]=counts.get(key,0)+wt
    pif=horizontal_flux(su,sw,z,zf,dx,cutoffs) if member!='packet_null' else np.zeros((len(cutoffs),nz))
    for tag,(lo,hi) in {'top0125':(-.125,0),'top025':(-.25,0),'full':(-.4,0)}.items():
     for kc,val in zip(cutoffs,pif@weight(z,lo,hi)):hflux.append([t,tag,float(kc),float(val)])
   cum=current;cumpv=pvcur
  if j%56==0:print(name,'frame',j,'elapsed',round(time.time()-start),flush=True)
 for k,v in hist.items():D[k]=np.asarray(v)
 for k,v in cum.items():D['cum_'+k]=v
 for k,v in cumlocal.items():D['cumlocal_'+k]=v[:,::8];D['cumfov_'+k]=v[:,fov].mean(1)
 D['initial_us_mean']=initial_s.mean(1);D['final_us_mean']=lasts
 for k,v in cumpv.items():D['pv_'+k]=v
 for k,val in sums.items():D['avg_'+k]=val/counts[k]
 dU=D['U'][-1]-D['U'][0];total=sum(cum.values())-(lasts-initial_s.mean(1))
 proj={k:float(np.sum(v*dU*dz)/np.sum(dU*dU*dz)) for k,v in cum.items()}
 proj['stokes_subtraction']=float(-np.sum((lasts-initial_s.mean(1))*dU*dz)/np.sum(dU*dU*dz)) if np.any(dU) else 0.
 error=float(np.sqrt(np.sum((total-dU)**2*dz)/max(np.sum(dU*dU*dz),1e-50)))
 localchange=ue-initialE;localpred=sum(cumlocal.values())-(us-initial_s)
 localerr=float(np.linalg.norm(localpred-localchange)/max(np.linalg.norm(localchange),1e-30))
 deltaE=float(np.sum((D['U'][-1]**2-D['U'][0]**2)*dz)/dz.sum()/2)
 info={'name':name,'source':str(root),'pv':summary_pv(D['Q'],D['q2'],qz,D['t']),
  'momentum_projected_fraction':proj,'momentum_reconstruction_relative_error':error,'local_momentum_reconstruction_relative_error':localerr,
  'mean_energy_increment_by_component':work,'mean_energy_change':deltaE,'mean_energy_fraction_by_component':{k:v/max(abs(deltaE),1e-50) for k,v in work.items()},
  'PV_half_q2_budget':{tag:{k:float(weight(qz,max(lo,qz[0]),min(hi,qz[-1]))@v) for k,v in cumpv.items()} for tag,(lo,hi) in LAYERS.items()},
  'spectral_metrics':specmetrics,'horizontal_flux':hflux,'runtime_seconds':time.time()-start,
  'spectral_reference':'Packet+turbulence spectra subtract the packet-only Eulerian velocity at each time; no-wave spectra use their Eulerian velocity. Transfer is nonlinear self-transfer of this transverse-mean residual, not total 3D or background-interaction transfer. Packet-only transfer is not reported.',
  'phase_resolution_rad_s':float(2*np.pi/22.4),'nominal_eddy_time_s':.2/.017,'effective_packet_exposure_s':float(np.sqrt(np.pi)*2.8)}
 for tag,(lo,hi) in LAYERS.items():info['PV_half_q2_budget'][tag]['observed_half_q2_change']=float(weight(qz,max(lo,qz[0]),min(hi,qz[-1]))@(D['q2'][-1]-D['q2'][0])/2)
 out.mkdir(parents=True,exist_ok=True);np.savez_compressed(out/(name+'.npz'),**D);(out/(name+'.json')).write_text(json.dumps(info,indent=2)+'\n')
 print('DONE',name,round(time.time()-start),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('out',type=Path);a=p.parse_args()
 (packet if a.name.startswith('packet-') else mono)(a.name,a.out)
