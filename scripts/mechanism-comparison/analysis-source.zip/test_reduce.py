import numpy as np
from reduce import products,force,horizontal_flux,native_spectrum,local_spectrum,summary_pv
nx=nz=32;dx=dz=1/nx;zf=np.linspace(-1,0,nz+1);z=(zf[:-1]+zf[1:])/2;x=np.arange(nx)/nx
psi=sum(np.sin(2*np.pi*m*x[None,:]+.4*m)*np.sin(np.pi*n*(zf[:,None]+1))*.01 for m,n in [(1,2),(2,3),(3,1)])
u=-np.diff(psi,axis=0)/dz;w=(np.roll(psi,-1,axis=1)-psi)/dx
fu,fw=force(u,w,z,zf,dx)
E=np.mean(u*u)/2+np.sum(w[1:-1]**2)/(nx*nz)/2
hu,hw,weights=native_spectrum(u,w);pu,pw,_=native_spectrum(fu,fw)
en=(abs(hu)**2+abs(hw)**2)*weights/2;work=np.real(hu.conj()*pu+hw.conj()*pw)*weights
assert abs(en.sum()-E)<1e-14
assert abs(work.sum())<1e-12
for k,flux in zip([0,1,2,4],horizontal_flux(u,w,z,zf,dx,[0,1,2,4])):
 expected=-work[:,:k+1].sum();assert abs(flux.mean()-expected)<1e-12,(k,flux.mean(),expected)
_,_,_,_,met=local_spectrum(u,w,z,zf,1,-.5,0)
assert abs(met['resolved_stress_tapered']-met['cospectrum_sum'])<1e-14
q0=np.exp(2*z);Q=np.array([q0,np.ones(nz)*q0.mean()]);r=summary_pv(Q,Q*Q,z,np.array([0,1]))
assert abs(r['top05']['mean_profile_variance_ratio'])<1e-10
assert r['top05']['flat_fraction_final_relative_initial_gradient']==1
print('PASS: native Parseval, centered advection conservation, four independent filtered-transfer identities, stress cospectrum normalization, PV homogenization manufactured case. No fluid integration.')
